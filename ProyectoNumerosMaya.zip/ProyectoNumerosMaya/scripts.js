function operacion(op) {
    //Conversion
    num = parseInt(document.getElementById("id_num").value);

    document.getElementById("id_sec3").value = op.toString();
    document.getElementById("id_sec2").value = op.toString();
    document.getElementById("id_sec1").value = op.toString();

    if (num < 0) {
        alert("Introduce un valor positivo");
    }
    if (num > 400) 
    {
        alert("Introduce un valor menor a 400");
    }
    else {
        if (op == 'Calcular') {
            //Seccion 3
            Rnum3 = num % 400;
            Snum3 = num / 400;

            if (Math.trunc(Snum3) <= 0) {
                document.getElementById("id_sec3").value = " ";
            }
            else {
                document.getElementById("id_sec3").value = Snum3.toString();
            }
            //Seccion 2
            Rnum2 = num % 20;
            Snum2 = Rnum3 / 20;
            if (Snum3 == 1) {
                Snum2 = Math.trunc(Snum2);
                document.getElementById("id_sec2").value = Snum2.toString();
            }

            else if (Math.trunc(Snum2) <= 0) {
                document.getElementById("id_sec2").value = " ";
            }
            else {
                Snum2 = Math.trunc(Snum2);
                document.getElementById("id_sec2").value = Snum2.toString();
            }

            //Seccion 1
            Rnum1 = num % 1;
            Snum1 = Rnum2 / 1;

            document.getElementById("id_sec1").value = Snum1.toString();
        }
    }
}

function ConversionCI(OpCI) 
{
    //Mostrar
    num = parseInt(document.getElementById("id_num").value);
    var imagen3 = " "
    var imagen2 = " "
    var imagen1 = " "


    if (OpCI == 'Mostrar') 
    {
        //Seccion 3
        switch (Snum3) 
        {
            case 1:
                imagen3 = 'img/Numero1.png';
                imagen2 = 'img/Numero0.png';
                imagen1 = 'img/Numero0.png';
                break;
        }

        //Seccion 2

        if (Snum2 == 1) {
            imagen2 = 'img/Numero1.png';
        }

        if (Snum2 == 2) {
            imagen2 = 'img/Numero2.png';
        }

        if (Snum2 == 3) {
            imagen2 = 'img/Numero3.png';
        }

        if (Snum2 == 4) {
            imagen2 = 'img/Numero4.png';
        }

        if (Snum2 == 5) {
            imagen2 = 'img/Numero5.png';
        }

        if (Snum2 == 6) {
            imagen2 = 'img/Numero6.png';
        }

        if (Snum2 == 7) {
            imagen2 = 'img/Numero7.png';
        }

        if (Snum2 == 8) {
            imagen2 = 'img/Numero8.png';
        }

        if (Snum2 == 9) {
            imagen2 = 'img/Numero9.png';
        }

        if (Snum2 == 10) {
            imagen2 = 'img/Numero10.png';
        }

        if (Snum2 == 11) {
            imagen2 = 'img/Numero11.png';
        }

        if (Snum2 == 12) {
            imagen2 = 'img/Numero12.png';
        }

        if (Snum2 == 13) {
            imagen2 = 'img/Numero13.png';
        }

        if (Snum2 == 14) {
            imagen2 = 'img/Numero14.png';
        }

        if (Snum2 == 15) {
            imagen2 = 'img/Numero15.png';
        }

        if (Snum2 == 16) {
            imagen2 = 'img/Numero16.png';
        }

        if (Snum2 == 17) {
            imagen2 = 'img/Numero17.png';
        }

        if (Snum2 == 18) {
            imagen2 = 'img/Numero18.png';
        }

        if (Snum2 == 19) {
            imagen2 = 'img/Numero19.png';
        }



        //Seccion 1
        if (Snum1 == 0) {
            imagen1 = 'img/Numero0.png';
        }

        if (Snum1 == 1) {
            imagen1 = 'img/Numero1.png';
        }

        if (Snum1 == 2) {
            imagen1 = 'img/Numero2.png';
        }

        if (Snum1 == 3) {
            imagen1 = 'img/Numero3.png';
        }

        if (Snum1 == 4) {
            imagen1 = 'img/Numero4.png';
        }

        if (Snum1 == 5) {
            imagen1 = 'img/Numero5.png';
        }

        if (Snum1 == 6) {
            imagen1 = 'img/Numero6.png';
        }

        if (Snum1 == 7) {
            imagen1 = 'img/Numero7.png';
        }

        if (Snum1 == 8) {
            imagen1 = 'img/Numero8.png';
        }

        if (Snum1 == 9) {
            imagen1 = 'img/Numero9.png';
        }

        if (Snum1 == 10) {
            imagen1 = 'img/Numero10.png';
        }

        if (Snum1 == 11) {
            imagen1 = 'img/Numero11.png';
        }

        if (Snum1 == 12) {
            imagen1 = 'img/Numero12.png';
        }

        if (Snum1 == 13) {
            imagen1 = 'img/Numero13.png';
        }

        if (Snum1 == 14) {
            imagen1 = 'img/Numero14.png';
        }

        if (Snum1 == 15) {
            imagen1 = 'img/Numero15.png';
        }

        if (Snum1 == 16) {
            imagen1 = 'img/Numero16.png';
        }

        if (Snum1 == 17) {
            imagen1 = 'img/Numero17.png';
        }

        if (Snum1 == 18) {
            imagen1 = 'img/Numero18.png';
        }

        if (Snum1 == 19) {
            imagen1 = 'img/Numero19.png';
        }
        
        document.getElementById("ImagenBox3").src = imagen3
        document.getElementById("ImagenBox2").src = imagen2
        document.getElementById("ImagenBox1").src = imagen1
        
        if (num>400)
        {
           document.getElementById("ImagenBox3").src = " "
           document.getElementById("ImagenBox2").src = " "
           document.getElementById("ImagenBox1").src = " "
        }
    }
}